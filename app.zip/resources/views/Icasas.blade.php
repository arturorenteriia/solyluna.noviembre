@extends('master')
@section('navbar_menu')

  <div class="row">
      <div class="col s12 m12 l12 ">
        <div class="card-panel blue">
        <center><span class="white-text" ><h5>INDEPENDENT LIVING</h5>
          </span></center>
          
        </div>
      </div>
    </div>

@stop
@section('form_residencias')

  <!--Aqui va el contenido de la pagina-->

 <div class="row">
     

  
        <div class="col s12 m12 l3">
            <div class="card small hoverable">
              <div class="card-image"  alt="">
                  <a href="casasayulita" class="brand-logo"> <img src="images/casasayulita.jpg"  ></a>
                  <a href="casasayulita" class="brand-logo"><span class="card-title ">Casa Sayulita</span></a>
              </div>
              <div class="card-content">
                  <a href="casasayulita" class="brand-logo">  <p class="grey-text text-darken-2">A day in paradise  </p></a>
              </div>
              <div class="card-action">
                <a href="casasayulita">See more...</a>
              </div>
            </div>
          </div>
         

   
  
        
        <div class="col s12 m12 l3">
            <div class="card small hoverable">
              <div class="card-image">
                  <a href="residenciaamapa" class="brand-logo">  <img src="images/residenciaamapa.jpg" ></a>
                  <a href="residenciaamapa" class="brand-logo">   <span class="card-title ">Residencia Amapa</span></a>
              </div>
              <div class="card-content">
                  <a href="residenciaamapa" class="brand-logo">  <p class="grey-text text-darken-2">Perfect for you  </p></a>
              </div>
              <div class="card-action">
                <a href="residenciaamapa">See more...</a>
              </div>
            </div>
          </div>
         
         
  
          

         

        </div>
   



@stop


@section('piepagina')
@stop