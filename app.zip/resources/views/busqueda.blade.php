@extends('master')
@section('navbar_menu')

  <div class="row">
      <div class="col s12 m12 l12 ">
        <div class="card-panel blue">
        <center><span class="white-text" ><h5>HEALTHCARE SERVICES</h5>
          </span></center>
          
        </div>
      </div>
    </div>

@stop
@section('form_residencias')

  <!--Aqui va el contenido de la pagina-->

 <div class="row">
      <div class="col s9 m9 l9 ">
        <div class="col s9 m9 l6">
              <div class="card-panel white">
            <div class="card-panel ">

              
         </div>                           
        </div>
         
       
          
        </div>
      </div>
    </div>




@stop


@section('piepagina')
@stop