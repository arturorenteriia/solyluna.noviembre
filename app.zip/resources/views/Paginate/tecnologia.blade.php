@extends('master')
@section('navbar_menu')

  <div class="row">
      <div class="col s12 m12 l12 ">
        <div class="card-panel blue">
        <center><span class="white-text" ><h5>TECHNOLOGY</h5>
          </span></center>
          
        </div>
      </div>
    </div>

@stop
@section('form_residencias')

  <!--Aqui va el contenido de la pagina-->

 <div class="row">
      <div class="col s9 m9 l7">
        <div class="card-panel white">
        <center>
       <h4> Nos preocupamos por ti en todos los sentidos</h4>
          </center><div class="divider"></div>
        <div class="col s12 m5 l7">
        <div class="card-panel white col s12">
         <img src="images/ancianotecnologia.jpg" class="responsive-img" width="100%" alt="">
        </div>
    </div>
     <p class="grey-text text-darken-2" align="justify">
          En Sol & Luna Health Exclusive Resorts estamos a la vanguardia en la tecnologia, te ofrecemos los mejores servicios
          en tecnologia de punta para que tu estadia con nosotros sea una experiencia inolvidable.
          Te acercamos a tus seres queridos y amigos mediante el sistema de videollamada para que en cualquier momento puedas
          estar comunicarte con ellos y sentir que estan cerca de ti, tambien te acercamos con tu doctor, no importa si el esta
          del otro lado del mundo, con nuestra tecnologia sentiras que el esta contigo atendiendo tus necesidades y de esta manera
          tu salud estara en buenas manos.
          Contamos con camaras de seguridad las 24 horas y personal totalmente capacitado para cuidar  de ti en cualquier momento.
</p>
</center><div class="divider"></div>
<br>
        
 <center>
       <h5> Te acercamos a las personas que mas quieres.</h5>
          </center>
          <p class="grey-text text-darken-2" align="justify">
          Una de nuestras tecnologias que implentamos en Sol & Luna Health Exclusive Resorts, es la impementacion
          de videolladas a traves de SKYPE.</p>
          <div class="col s12 m5 l5">
        <div class="card-panel white col s12">
         <img src="images/skype.jpg" class="responsive-img" width="100%" alt="">
        </div>
    </div>
    <p class="grey-text text-darken-2" align="justify">
    Con este sistema usted podra comunicarte "cara a cara" con sus seres queridos y asi estar en contacto con ellos,
    Si usted quiere comunicarse con un huesped de Assisting Living o Memory Care, con SKYPE usted podra hacer una videollamada
    a la residencia o centro donde esta hospedado y nuestro personal directamente lo comunicara con la persona que usted desee,
    asi podra estar con comunicacion en cualquier hora del dia con ellos y estar al pendiente de lo que pase.

</p>
</center><div class="divider"></div>
<br>
        
 <center>
       <h5> Tu doctor a tu lado, siempre.</h5>
          </center>
          <p class="grey-text text-darken-2" align="justify">
          Una de nuestras tecnologias que implentamos en Sol & Luna Health Exclusive Resorts, es la impementacion
          de videolladas a traves de SKYPE.</p>
          <div class="col s12 m5 l3">
        <div class="card-panel white col s12">
         <img src="images/videollamadadoctor.png" class="responsive-img" width="100%" alt="">
        </div>
    </div>
    <p class="grey-text text-darken-2" align="justify">
    Con este sistema usted podra comunicarte "cara a cara" con sus seres queridos y asi estar en contacto con ellos,
    Si usted quiere comunicarse con un huesped de Assisting Living o Memory Care, con SKYPE usted podra hacer una videollamada
    a la residencia o centro donde esta hospedado y nuestro personal directamente lo comunicara con la persona que usted desee,
    asi podra estar con comunicacion en cualquier hora del dia con ellos y estar al pendiente de lo que pase.

</p>

        </div>
      </div>
    </div>




@stop


@section('piepagina')
@stop