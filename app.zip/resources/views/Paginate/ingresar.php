<?php 


$nombre= $_POST['select3'];
if ($nombre == "Sayulita") {
	echo "Bienvenido a Sayulita";

} else {echo "no es Sayulita";}


?>