<?php namespace solyluna;

use Illuminate\Database\Eloquent\Model;

class RateAssisting extends Model {

	//

}
