<?php namespace solyluna;

use Illuminate\Database\Eloquent\Model;

class State extends Model {

	//

}
