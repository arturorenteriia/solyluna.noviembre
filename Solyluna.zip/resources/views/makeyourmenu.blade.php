@extends('master')
@section('navbar_menu')

  <div class="row">
      <div class="col s12 m12 l12 ">
        <div class="card-panel blue">
        <center><span class="white-text" ><h5>MAKE YOUR MENU!</h5>
          </span></center>
          
        </div>
      </div>
    </div>

@stop
@section('form_residencias')

<div class="row">
      <div class="col s12 m12 l7 ">
        <div class="card-panel white">
        <center><span class="Black" >
      

        	<div class="col s5 m5 l3">
        <div class="card-panel white">
         <img src="images/personaliza tu menu.jpg" class="responsive-img" width="90%" alt="">
        </div>
      </div>
        <p class="grey-text text-darken-2" align="justify">
        	Con <b>Make your Menu!</b> de Sol y Luna Exclusive Resorts usted puede crear un menu semanal personalizado que a su vez este le llegara al chef para que
        	el se lo prepare, puede elegir entre una gran variedad de platillos y bebidas a su antojo, 

        	o si usted cuenta con un residente en Memory Care
        	tambien le puede preparar el menu semanal para esa persona especial.
        	<br>
        	Con <b>Make your Menu!</b> de Sol y Luna Exclusive Resorts usted puede crear un menu semanal personalizado que a su vez este le llegara al chef para que
        	el se lo prepare, puede elegir entre una gran variedad de platillos y bebidas a su antojo, 

        	o si usted cuenta con un residente en Memory Care
        	tambien le puede preparar el menu semanal para esa persona especial.


        </p>

        	  <span><a class="btn" role="button" href="home"><i class="material-icons"></i>Make Your Menu!</a></span>
          </span></center>
          
        </div>
      </div>
    </div>
 
@stop


@section('piepagina')
@stop