<?php namespace solyluna;

use Illuminate\Database\Eloquent\Model;

class TextAssited extends Model {

    protected $fillable = ['title1', 'text1', 'title2', 'text2'];

}
