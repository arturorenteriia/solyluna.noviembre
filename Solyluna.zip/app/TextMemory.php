<?php namespace solyluna;

use Illuminate\Database\Eloquent\Model;

class TextMemory extends Model {

    protected $fillable = ['title1', 'text1', 'title2', 'text2'];

}
