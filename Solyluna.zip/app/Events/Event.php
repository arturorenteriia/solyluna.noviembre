<?php namespace solyluna\Events;

abstract class Event {

	//

}
