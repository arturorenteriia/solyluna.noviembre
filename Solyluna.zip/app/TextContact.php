<?php namespace solyluna;

use Illuminate\Database\Eloquent\Model;

class TextContact extends Model {

    protected $fillable = ['title1', 'text1', 'text2', 'text3'];

}
