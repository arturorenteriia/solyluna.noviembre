<?php namespace solyluna\Commands;

abstract class Command {

	//

}
